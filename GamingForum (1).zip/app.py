
from flask import Flask, render_template, request, redirect, url_for
import sqlite3

app = Flask(__name__)

# Создание базы данных
def init_db():
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT, email TEXT, password TEXT)''')
    c.execute('''CREATE TABLE IF NOT EXISTS comments (id INTEGER PRIMARY KEY, topic TEXT, content TEXT)''')
    conn.commit()
    conn.close()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/discussion')
def discussion():
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute("SELECT topic, content FROM comments")
    comments = c.fetchall()
    conn.close()
    return render_template('discussion.html', comments=comments)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        conn = sqlite3.connect('database.db')
        c = conn.cursor()
        c.execute("INSERT INTO users (username, email, password) VALUES (?, ?, ?)", (username, email, password))
        conn.commit()
        conn.close()
        return redirect(url_for('home'))
    return render_template('register.html')

@app.route('/add_comment', methods=['POST'])
def add_comment():
    topic = request.form['topic']
    content = request.form['content']
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute("INSERT INTO comments (topic, content) VALUES (?, ?)", (topic, content))
    conn.commit()
    conn.close()
    return redirect(url_for('discussion'))

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
